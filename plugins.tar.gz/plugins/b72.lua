
do
    
local function run(msg,matches)
    if matches[1] == "chat_add_user"  then 
      return "بنؤؤؤؤر   القالي 🌝✋🏻 \n".."️ اسم الضافك 👥 \n"..(msg.from.first_name or " ").."\n".."تابع شعرات صدري 🌞👈🏻{@b7_78}"
    elseif matches[1] == "chat_add_user_link" then
      return "بنؤؤؤؤؤر القالي 🌝✋🏻\n"..(msg.from.first_name or " ").."\n".."تابع سعرات صدري 🌞👈🏻{@b7_78}"

    end
    if matches[1] == "chat_del_user" then
    return '#دي# 😑😹\n'..msg.action.user.first_name..'\n'
end
end
return {
    patterns = {
        "^!!tgservice (chat_add_user)$",
        "^!!tgservice (chat_add_user_link)$",
        "^!!tgservice (chat_del_user)$"
       
    },
 run = run,
}
end