--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
              CH > @lTSHAKEl_CH
--]]
do

function run(msg, matches)
  local tshake = {'ها شتريد 😒','نعم حبيبي 💋','تفضل ؟','حياته',' نعم ',' شكو ؟ ',' حياته 😻 وعيونه 🙄 وكلبه ❤️'}
  return tshake[math.random(#بوت)]
end

return {
  description = "tshake face",
  usage = "send tshake random  ",
  patterns = {"بوت"},
  run = run
}

end
--dev : @b7_78

--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
              CH > @lTSHAKEl_CH
--]]--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
              CH > @lTSHAKEl_CH
--]]
do

function run(msg, matches)
  local tshake = {'ها شتريد 😒','نعم حبيبي 💋','تفضل ؟','حياته',' نعم ',' شكو ؟ ',' حياته 😻 وعيونه 🙄 وكلبه ❤️'}
  return tshake[math.random(#بوت)]
end

return {
  description = "tshake face",
  usage = "send tshake random  ",
  patterns = {"بوت"},
  run = run
}

end
--dev : @b7_78

--[[ 
    _____    _        _    _    _____    Dev @lIMyIl 
   |_   _|__| |__    / \  | | _| ____|   Dev @li_XxX_il
     | |/ __| '_ \  / _ \ | |/ /  _|     Dev @h_k_a
     | |\__ \ | | |/ ___ \|   <| |___    Dev @Aram_omar22
     |_||___/_| |_/_/   \_\_|\_\_____|   Dev @IXX_I_XXI
              CH > @lTSHAKEl_CH
--]]